#########################
#1. Data import
##########################
rm(list=ls())
Data<-3
#Data 1
#setwd('D:/Dropbox/YG-Projects/Paper3_data/Angrist_Krueger/')
#setwd('C:/Users/Goh/Dropbox/YG-Projects/Paper3_data/Angrist_Krueger/')
setwd('/Users/jisangyu/Dropbox/High_dimensional_Bayesian/Paper3_data/Angrist_Krueger/')

if(Data==1){
AJRdata0<-read.csv("Angrist_Krueger_20_29_data.csv",header=TRUE)
}
#Data 2
if(Data==2){
AJRdata0<-read.csv("Angrist_Krueger_30_39_data.csv",header=TRUE)
}
#Data 3
if(Data==3){
AJRdata0<-read.csv("Angrist_Krueger_40_49_data.csv",header=TRUE)
}
set.seed(12345)
#################################
#Data centered by the mean
AJRdata<-AJRdata0
y<-as.numeric(AJRdata[,1])-mean(as.numeric(AJRdata[,1]))
d<-as.numeric(AJRdata[,2])-mean(as.numeric(AJRdata[,2]))
n<-length(y)
X<-scale(as.matrix(AJRdata[,-c(1,2)]),center=TRUE,scale=FALSE)[,]

###########################
IVs.name<-colnames(X)

####################
####################

####################################################
#1. naive TSLS
####################################################
Angrist.IVs<-c(10:39)
A<-c(1:9)
#IVs.name[Angrist.IVs]
Z<-X[,c(A,Angrist.IVs)]
L<-dim(Z)[2]

hat.d<-Z%*%(solve(crossprod(Z))%*%(t(Z)%*%d))
M.z_A_hat.d<-hat.d-Z[,A]%*%(solve(crossprod(Z[,A]))%*%(t(Z[,A])%*%hat.d))
tdMd<-as.numeric(t(hat.d)%*%M.z_A_hat.d)
M.z_A_y<-y-Z[,A]%*%(solve(crossprod(Z[,A]))%*%(t(Z[,A])%*%y))
hat.beta.TSLS<-as.numeric(t(hat.d)%*%(M.z_A_y))/tdMd
M_hat.d_Z.A<-Z[,A]-hat.d%*%(t(hat.d)%*%Z[,A])/sum((hat.d)^2)
M_hat.d_y<-y-hat.d%*%(t(hat.d)%*%y)/sum((hat.d)^2)
hat.alpha.TSLS<-solve(t(Z[,A])%*%M_hat.d_Z.A)%*%(t(Z[,A])%*%M_hat.d_y)
hat.sig2.TSLS<-sum((y-d*hat.beta.TSLS-Z[,A]%*%hat.alpha.TSLS)^2)/n
hat.se.TSLS<-sqrt(hat.sig2.TSLS/tdMd)

hat.beta.naive<-hat.beta.TSLS #Estimate of Naive TSLS
hat.se.naive<-hat.se.TSLS #SE of Naive TSLS
##################################################

################
# LASSO methods
################
library(glmnet)
P.z.y<-Z%*%(solve(t(Z)%*%Z)%*%(t(Z)%*%y))
y.lasso<-as.numeric((P.z.y-(hat.d%*%(t(hat.d)%*%P.z.y))/as.numeric(t(hat.d)%*%hat.d)))
X.lasso<-(Z-(hat.d%*%(t(hat.d)%*%Z))/as.numeric(t(hat.d)%*%hat.d))
Ex.var<-1:9
inclusion.ind<-rep(1,L)
inclusion.ind[Ex.var]<-0
cvfit = cv.glmnet(X.lasso,y.lasso,intercept=FALSE,penalty.factor =inclusion.ind)
#################
#2. LASSO  
#################
hat.alpha.lasso.cv<-as.numeric(coef(cvfit, s = "lambda.min"))[-1]
hat.beta.lasso.cv<-as.numeric(t(hat.d)%*%(y-Z%*%hat.alpha.lasso.cv))/as.numeric(sum(hat.d^2)) #Estimate of Lasso

#################
#3. Post-LASSO 
#################
L<-dim(Z)[2]
A<-which(hat.alpha.lasso.cv!=0)
A.lasso<-A #Selected invalid IVs by Lasso
if(length(A)==L){
hat.beta.post_lasso<-NA
hat.se.post_lasso<-NA}else{

hat.d<-Z%*%(solve(crossprod(Z))%*%(t(Z)%*%d))
M.z_A_hat.d<-hat.d-Z[,A]%*%(solve(crossprod(Z[,A]))%*%(t(Z[,A])%*%hat.d))
tdMd<-as.numeric(t(hat.d)%*%M.z_A_hat.d)
M.z_A_y<-y-Z[,A]%*%(solve(crossprod(Z[,A]))%*%(t(Z[,A])%*%y))
hat.beta.TSLS<-as.numeric(t(hat.d)%*%(M.z_A_y))/tdMd
M_hat.d_Z.A<-Z[,A]-hat.d%*%(t(hat.d)%*%Z[,A])/sum((hat.d)^2)
M_hat.d_y<-y-hat.d%*%(t(hat.d)%*%y)/sum((hat.d)^2)
hat.alpha.TSLS<-solve(t(Z[,A])%*%M_hat.d_Z.A)%*%(t(Z[,A])%*%M_hat.d_y)
hat.sig2.TSLS<-sum((y-d*hat.beta.TSLS-Z[,A]%*%hat.alpha.TSLS)^2)/n
hat.se.TSLS<-sqrt(hat.sig2.TSLS/tdMd)
hat.beta.post_lasso<-hat.beta.TSLS #Estimate of Post-lasso
hat.alpha.post_lasso<-hat.alpha.TSLS
hat.sig2.post_lasso<-hat.sig2.TSLS
hat.se.post_lasso<-hat.se.TSLS #SE of Post-lasso
}




#################
#Adaptive Lasso methods
#################


#######################################################
# Median (Han's) estimator for adaptive lasso weights
#######################################################
Ex.var<-1:9
gamma.j<-t(Z[,-Ex.var])%*%(d-Z[,Ex.var]%*%(solve(crossprod(Z[,Ex.var]))%*%(t(Z[,Ex.var])%*%d)) )
Gamma.j<-t(Z[,-Ex.var])%*%(y-Z[,Ex.var]%*%(solve(crossprod(Z[,Ex.var]))%*%(t(Z[,Ex.var])%*%y)) )
tilde.beta<-as.numeric(Gamma.j/gamma.j)
hat.beta.m<-median(tilde.beta)
hat.alpha.m<-as.numeric(solve(crossprod(Z[,Ex.var]))%*%(t(Z[,Ex.var])%*%(y-d*hat.beta.m)))
hat.sig2.m<-sum((y-cbind(d,Z[,Ex.var])%*%c(hat.beta.m,hat.alpha.m))^2)/n
#########################

hat.alpha.m<-as.numeric(solve(crossprod(Z))%*%(t(Z)%*%(y-d*hat.beta.m)))
weight.a<-1/abs(hat.alpha.m)
weight.a[Ex.var]<-0
cvfit_alasso=cv.glmnet(X.lasso, y.lasso,intercept=FALSE,penalty.factor=weight.a)
###########
#################
#4. Adaptive Lasso
#################
hat.alpha.alasso.cv<-as.numeric(coef(cvfit_alasso, s = "lambda.min"))[-1]
hat.beta.alasso.cv<-as.numeric(t(hat.d)%*%(y-Z%*%hat.alpha.alasso.cv))/as.numeric(t(hat.d)%*%hat.d) #Estimate of Adaptive lasso
#################
#5. Post-Adaptive Lasso
#################
A<-which(hat.alpha.alasso.cv!=0)
A.alasso<-A #Selected invalid IVs by Adaptive Lasso
if(length(A)==L){
hat.beta.post_alasso<-NA
hat.se.post_alasso<-NA}else{

hat.d<-Z%*%(solve(crossprod(Z))%*%(t(Z)%*%d))
M.z_A_hat.d<-hat.d-Z[,A]%*%(solve(crossprod(Z[,A]))%*%(t(Z[,A])%*%hat.d))
tdMd<-as.numeric(t(hat.d)%*%M.z_A_hat.d)
M.z_A_y<-y-Z[,A]%*%(solve(crossprod(Z[,A]))%*%(t(Z[,A])%*%y))
hat.beta.TSLS<-as.numeric(t(hat.d)%*%(M.z_A_y))/tdMd
M_hat.d_Z.A<-Z[,A]-hat.d%*%(t(hat.d)%*%Z[,A])/sum((hat.d)^2)
M_hat.d_y<-y-hat.d%*%(t(hat.d)%*%y)/sum((hat.d)^2)
hat.alpha.TSLS<-solve(t(Z[,A])%*%M_hat.d_Z.A)%*%(t(Z[,A])%*%M_hat.d_y)
hat.sig2.TSLS<-sum((y-d*hat.beta.TSLS-Z[,A]%*%hat.alpha.TSLS)^2)/n
hat.se.TSLS<-sqrt(hat.sig2.TSLS/tdMd)
hat.beta.post_alasso<-hat.beta.TSLS #Estimate of post-adaptive lasso
hat.alpha.post_alasso<-hat.alpha.TSLS
hat.sig2.post_alasso<-hat.sig2.TSLS
hat.se.post_alasso<-hat.se.TSLS #SE of post-adaptive lasso
}


################################
#6. Proposed Stochastic Search
################################
# Step0. Initial value setting
####################################
names.Var<-colnames(Z)
MCMC.gamma<-rep(0,L)    #null model
MCMC.gamma[Ex.var]<-1
SS.size<-1000        #SSS iteration.size
cut.off<-log(3)
cut.off2<-Inf
delta0<-1/10^5
tau<-0.1
D<-diag(c(delta0,rep(0,L)))
#################################### 
P.z.y<-Z%*%(solve(t(Z)%*%Z)%*%(t(Z)%*%y))
max.log.post<--Inf
##############################
IV.1<-10 #position of 1st Possible IV

############
final.cand.prob<-c()
final.cand.models<-c()

#Begin: Revised by Goh
for(mcmc.goh in 1:SS.size){
log.post.N<-rep(-Inf,L)
cand.model.N<-matrix(0,L,L)
#Step 1: Compute nbd
for(ii in IV.1:L){
MCMC.gamma.new<-MCMC.gamma
MCMC.gamma.new[ii]<-1-MCMC.gamma[ii]
cand.model.N[ii,]<-MCMC.gamma.new
}
for(ii in IV.1:L){
MCMC.gamma.nbd<-cand.model.N[ii,]
if(sum(MCMC.gamma.nbd)<L/2){
hat.R<-cbind(hat.d,Z[,MCMC.gamma.nbd==1])
R<-cbind(d,Z[,MCMC.gamma.nbd==1])
hat.tRR<-crossprod(hat.R)
####################
#hat.sig2 ##########
inv.tRR<-solve(hat.tRR)
tilde.theta.w<-inv.tRR%*%(t(hat.R)%*%y)
hat.y.w<-(R%*%tilde.theta.w)
hat.sig2<-sum((y-hat.y.w)^2)/n

#log Post prob #########
W<-c(1,which(MCMC.gamma.nbd==1)+1)
tRPR_delta0<-hat.tRR+hat.sig2*D[W,W]
inv.tRPR_delta0<-solve(tRPR_delta0)
hat.theta.w<-inv.tRPR_delta0%*%(t(hat.R)%*%y)
P.z.hat.y<-(hat.R%*%hat.theta.w)

log.post.ii<-as.numeric((sum(MCMC.gamma.nbd)+1-L)/2*log(2*pi*hat.sig2)-
1/2*(determinant(tRPR_delta0,logarithm = TRUE)$modulus[1])-
1/(2*hat.sig2)*sum((P.z.y-P.z.hat.y)^2))-
delta0/2*(hat.theta.w[1]^2)
log.post.N[ii]<-log.post.ii 
if(max.log.post<=(log.post.ii+cut.off)){
if(!is.element(log.post.ii,final.cand.prob)){
final.cand.prob<-c(final.cand.prob,log.post.ii)
max.log.post<-max(final.cand.prob)
final.cand.models<-rbind(final.cand.models,MCMC.gamma.nbd)
#update A
A<-which((max.log.post-final.cand.prob)<=cut.off)
final.cand.prob<-final.cand.prob[A]
final.cand.models<-final.cand.models[A,]
}} 
	}
}

prob.prop.N<-exp(tau*log.post.N-tau*max(log.post.N))
prob.N<-prob.prop.N/sum(prob.prop.N)
jj.SSS<-sample(1:L,1,prob=prob.N)
MCMC.gamma.old.jj<-MCMC.gamma[jj.SSS]
MCMC.gamma[jj.SSS]<-1-MCMC.gamma.old.jj
print(paste("MCMC rep=",mcmc.goh) )
print(final.cand.models)
}

final.cand<-1:length(final.cand.prob) 
prop.prob.cand<-exp(final.cand.prob)
prob.BMA<-prop.prob.cand/sum(prop.prob.cand)

##########################################
beta.proposed.BMA<-0*prob.BMA
var.proposed.BMA<-0*prob.BMA

for(A.i in final.cand){

if(length(final.cand)==1){
MCMC.gamma<-final.cand.models
}else{
MCMC.gamma<-final.cand.models[A.i,]
}
print(which(MCMC.gamma==1))

hat.R<-cbind(hat.d,Z[,MCMC.gamma==1])
R<-cbind(d,Z[,MCMC.gamma==1])
hat.tRR<-crossprod(hat.R)
####################
#hat.sig2 ##########
inv.tRR<-solve(hat.tRR)
tilde.theta.w<-inv.tRR%*%(t(hat.R)%*%y)
hat.y.w<-(R%*%tilde.theta.w)
hat.sig2<-sum((y-hat.y.w)^2)/n
#log Post prob #########
########################
W<-c(1,which(MCMC.gamma==1)+1)
tRPR_delta0<-hat.tRR+hat.sig2*D[W,W]
inv.tRPR_delta0<-solve(tRPR_delta0)
hat.theta.w<-inv.tRPR_delta0%*%(t(hat.R)%*%y)

beta.proposed.BMA[A.i]<-hat.theta.w[1]
var.proposed.BMA[A.i]<-hat.sig2*inv.tRPR_delta0[1,1]
}

#####################
#BMA formula 
#####################
hat.beta.BMA<-sum(beta.proposed.BMA*prob.BMA)
hat.se.BMA<-sqrt(sum((var.proposed.BMA+beta.proposed.BMA^2)*prob.BMA)-hat.beta.BMA^2)

#End: Revised by Goh
#################

Est.summary<-matrix(0,2,6)
colnames(Est.summary)<-c("TSLS_naive","Lasso","Post_Lasso","Alasso","Post_Alasso","Proposed Bayes")
row.names(Est.summary)<-c("Est","SE")
Est.summary[1,]<-c(hat.beta.naive,hat.beta.lasso.cv,hat.beta.post_lasso,hat.beta.alasso.cv,hat.beta.post_alasso,hat.beta.BMA)
Est.summary[2,]<-c(hat.se.naive,NA,hat.se.post_lasso,NA,hat.se.post_alasso,hat.se.BMA)
library(xtable)
xtable(t(Est.summary),digit=4)
##########################################################
##########################################################

#################################################

Var.select<-matrix(100,30,4)
#row.names(Var.select)<-IVs.name[Angrist.IVs]
row.names(Var.select)<-1:30

colnames(Var.select)<-c("Naive","Lasso","Alasso","Bayes")
Var.select[(A.lasso[-(1:9)]-9),2]<-0
Var.select[(A.alasso[-(1:9)]-9),3]<-0
Marginal.Prob<-rep(0,(L-IV.1+1))
for(i in 1:length(final.cand)){
if(length(final.cand)==1){
MCMC.gamma<-final.cand.models
}else{
MCMC.gamma<-final.cand.models[i,]
}
Marginal.Prob<-Marginal.Prob+(1-MCMC.gamma[IV.1:L])*prob.BMA[i]
}
Var.select[,4]<-Marginal.Prob*100
xtable(Var.select,digit=1)



