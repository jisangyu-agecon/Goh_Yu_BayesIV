rm(list=ls())
library(mvtnorm)
library(glmnet) #for LASSO and Adaptive lasso 
library(gtools) #for permultations function
library(KScorrect)

MC.size<-3000 #Size of Monte Carlo simulation for each setting 

n<-2000
Seed.count<-0

for(Model in 1:2){
for(Scenario in c("a","b","c","d")){

Seed.count<-Seed.count+1
##########################
L<-12 #number of potential IVs
s<-3 #number of invalid IVs

if(Scenario=="a"){
beta<-0 
eta<-rep(0.4,L)
}
if(Scenario=="b"){
beta<-0 
eta<-rep(0.2,L)
eta[1:s]<-0.6
}
if(Scenario=="c"){
beta<-0.5 
eta<-rep(0.4,L)
}
if(Scenario=="d"){
beta<-0.5 
eta<-rep(0.2,L)
eta[1:s]<-0.6
}

#######################################
Est.summary<-matrix(0,MC.size,9)
colnames(Est.summary)<-c("2SLS_or","2SLS_naive","Han_Median","Lasso_cv","Post_Lasso","Alasso_cv","Post_Alasso","BMA","BMA_SSS")
Est.CP<-matrix(0,MC.size,6)
Est.Var<-matrix(0,MC.size,6)
colnames(Est.CP)<-c("2SLS_or","2SLS_naive","Post_Lasso","Post_Alasso","BMA","BMA_SSS")

############################
#Simulatino Starts 
############################
set.seed((1230+Seed.count)) #for the purpose of reproducibility

for(goh in 1:MC.size){

#############################################
# Data Generating Process
#############################################
Cov.e<-matrix(c(1,0.25,0.25,1),2,2)
alpha<-rep(0,L)
alpha[1:s]<-0.5
Z<-matrix(rnorm(n*L,0,1),n,L) 
E<-rmvnorm(n,c(0,0),Cov.e,method="chol")
if(Model==1){ #Gaussian error
epsilon<-E[,1]
nu<-E[,2]}
if(Model==2){ #Laplace error
v.i<-rexp(n,1)
epsilon<-sqrt(v.i)*E[,1]
nu<-sqrt(v.i)*E[,2]}


d<-as.numeric(Z%*%eta)+nu
y<-d*beta+as.numeric(Z%*%alpha)+epsilon

##############################################
#Data Centering ##############################
##############################################
y<-(y-mean(y))
Z<-scale(Z,center = TRUE, scale = FALSE)[,]
d<-(d-mean(d))
##############################################

######################
#1. Oracle 2SLS
######################
I.n<-diag(1,n)
P.z<-Z%*%solve(t(Z)%*%Z)%*%t(Z)
hat.d<-P.z%*%d
A<-which(alpha!=0) # A is "omega" in the manuscript 
P.z_A<-Z[,A]%*%solve(crossprod(Z[,A]))%*%t(Z[,A])
M.z_A<-I.n-P.z_A
tdMd<-as.numeric(t(hat.d)%*%(M.z_A%*%hat.d))
hat.beta.or<-as.numeric(t(hat.d)%*%(M.z_A%*%y))/tdMd #oracle 2SLS estimate
M_hat.d<-I.n-crossprod(t(hat.d))/sum((hat.d)^2)
P.z.hat.d<-t(Z[,A])%*%M_hat.d
hat.R<-cbind(hat.d,Z[,A])
tRR.A<-crossprod(hat.R)
hat.theta<-solve(tRR.A)%*%t(hat.R)%*%y
hat.sig2.or<-sum((y-cbind(d,Z[,A])%*%hat.theta)^2)/n
hat.se.or<-sqrt(hat.sig2.or/tdMd) #s.e. of oracle 2SLS estimate

######################
#2. naive 2SLS
######################
hat.beta.naive<-as.numeric((t(hat.d)%*%y)/(t(hat.d)%*%hat.d)) #naive 2SLS estimate
tdd<-as.numeric(t(hat.d)%*%hat.d)
hat.sig2.naive<-sum((y-d*hat.beta.naive)^2)/n
hat.se.naive<-sqrt(hat.sig2.naive/tdd) #s.e. of naive 2SLS estimate

#############################
#3. Median (Han's) estimator
#############################
inv.tZZtZ<-solve(crossprod(Z))%*%t(Z)
hat.beta.m<-median(as.numeric(inv.tZZtZ%*%y)/as.numeric(inv.tZZtZ%*%d)) #median estimate
#hat.alpha.m<-as.numeric(inv.tZZtZ%*%(y-d*hat.beta.m))
#hat.sig2.m<-sum((y-cbind(d,Z)%*%c(hat.beta.m,hat.alpha.m))^2)/n

#############################

################
#LASSO methods
################
y.lasso<-as.numeric(M_hat.d%*%(P.z%*%y))
X.lasso<-M_hat.d%*%Z
cvfit = cv.glmnet(X.lasso,y.lasso,intercept=FALSE)

#################
#4.LASSO 
#################
hat.alpha.lasso.cv<-as.numeric(coef(cvfit, s = "lambda.min"))[-1]
hat.beta.lasso.cv<-as.numeric(t(hat.d)%*%(y-Z%*%hat.alpha.lasso.cv))/as.numeric(sum(hat.d^2)) #Lasso estimate

#################
#5.Post_LASSO
#################
A<-which(hat.alpha.lasso.cv!=0)
if(length(A)==L){
hat.beta.post_lasso<-hat.beta.naive
hat.se.post_lasso<-hat.se.naive}else{
P.z_A<-Z[,A]%*%solve(crossprod(Z[,A]))%*%t(Z[,A])
M.z_A<-I.n-P.z_A
tdMd<-as.numeric(t(hat.d)%*%(M.z_A%*%hat.d))
hat.beta.post_lasso<-as.numeric(t(hat.d)%*%(M.z_A%*%y))/tdMd #post-lasso estimate
hat.alpha.post_lasso<-solve(t(Z[,A])%*%M_hat.d%*%Z[,A])%*%t(Z[,A])%*%M_hat.d%*%y
hat.sig2.post_lasso<-sum((y-d*hat.beta.post_lasso-Z[,A]%*%hat.alpha.post_lasso)^2)/n
hat.se.post_lasso<-sqrt(hat.sig2.post_lasso/tdMd) #s.e. of post-lasso estimate
}

############################
#Adaptive Lasso methods
############################
hat.alpha.m<-as.numeric(inv.tZZtZ%*%(y-d*hat.beta.m)) 
cvfit_alasso=cv.glmnet(X.lasso, y.lasso,intercept=FALSE,penalty.factor = 1/abs(hat.alpha.m))
############################
#6. adaptive lasso
############################
hat.alpha.alasso.cv<-as.numeric(coef(cvfit_alasso, s = "lambda.min"))[-1]
hat.beta.alasso.cv<-as.numeric(t(hat.d)%*%(y-Z%*%hat.alpha.alasso.cv))/as.numeric(t(hat.d)%*%hat.d) #adaptive lasso estimate
#################
#7.post-adaptive lasso
#################
A<-which(hat.alpha.alasso.cv!=0)
if(length(A)==L){
hat.beta.post_alasso<-hat.beta.naive
hat.se.post_alasso<-hat.se.naive}else{
P.z_A<-Z[,A]%*%solve(t(Z[,A])%*%Z[,A])%*%t(Z[,A])
M.z_A<-I.n-P.z_A
tdMd<-as.numeric(t(hat.d)%*%M.z_A%*%hat.d)
hat.beta.post_alasso<-as.numeric(t(hat.d)%*%M.z_A%*%y)/tdMd #post-alasso estimate
hat.alpha.post_alasso<-solve(t(Z[,A])%*%M_hat.d%*%Z[,A])%*%t(Z[,A])%*%M_hat.d%*%y
hat.sig2.post_alasso<-sum((y-d*hat.beta.post_alasso-Z[,A]%*%hat.alpha.post_alasso)^2)/n
hat.se.post_alasso<-sqrt(hat.sig2.post_alasso/tdMd) #e.s. of post-alasso estimate
}


##########################################
#7. Traditional Bayes (BMA)   ############
##########################################

##########################
#all possible candidates #
if(goh==1){ 
model.cand <- c(0, 1)
all.model<-permutations(n=2,r=L,v=model.cand,repeats.allowed=T)
n.model<-dim(all.model)[1]
}

delta0<-1/10^5
###########################
P.z.y<-P.z%*%y
log.post.all<-rep(-Inf,n.model)
beta.all<-rep(0,n.model)
var.all<-rep(0,n.model)
##############################
D<-diag(c(delta0,rep(0,L)))

for(goh.bma in 1:n.model){
MCMC.gamma<-all.model[goh.bma,]
if(sum(MCMC.gamma)<L/2){
hat.R<-cbind(hat.d,Z[,MCMC.gamma==1])
R<-cbind(d,Z[,MCMC.gamma==1])
hat.tRR<-crossprod(hat.R)
####################
#hat.sig2 ##########
inv.tRR<-solve(hat.tRR)
tilde.theta.w<-inv.tRR%*%(t(hat.R)%*%y)
hat.y.w<-(R%*%tilde.theta.w)
hat.sig2<- sum((y-hat.y.w)^2)/n
#log Post prob #########
########################
W<-c(1,which(MCMC.gamma==1)+1)
tRPR_delta0<-hat.tRR+hat.sig2*D[W,W]
inv.tRPR_delta0<-solve(tRPR_delta0)
hat.theta.w<-inv.tRPR_delta0%*%(t(hat.R)%*%y)
P.z.hat.y<-(hat.R%*%hat.theta.w)
#log-marginal likelihood evaluation
log.post.all[goh.bma]<-as.numeric((sum(MCMC.gamma)+1-L)/2*log(2*pi*hat.sig2)-
1/2*(determinant(tRPR_delta0,logarithm = TRUE)$modulus[1])-
1/(2*hat.sig2)*sum((P.z.y-P.z.hat.y)^2))-
delta0/2*(hat.theta.w[1]^2)

beta.all[goh.bma]<-hat.theta.w[1]
#posterior variance of beta
var.all[goh.bma]<-hat.sig2*inv.tRPR_delta0[1,1]
	}
}

best<-which.max(log.post.all)
final.cand<-which((log.post.all[best]-log.post.all)<Inf)
prop.prob.cand<-exp(log.post.all[final.cand]-log.post.all[best])
prob.BMA<-prop.prob.cand/sum(prop.prob.cand)
beta.BMA<-beta.all[final.cand]
var.BMA<-var.all[final.cand]

hat.beta.BMA<-sum(beta.BMA*prob.BMA) # est of BMA-beta
hat.se.BMA<-sqrt(sum((var.BMA+beta.BMA^2)*prob.BMA)-hat.beta.BMA^2) #sd of BMA-beta

################################
#8. Proposed Stochastic Search
################################
#Step0. Initial value setting
################################
MCMC.gamma<-rep(0,L) # start with the null model
P.z.y<-P.z%*%y
max.log.post<--Inf
SS.size<-1000 #Iteration number of stochastic search
tau<-0.1
cut.off<-log(3) # which corresponds to c=3 in Eq (7) in the manuscript

D<-diag(c(delta0,rep(0,L)))

####################################
#Step1. Evaluating neighbor models
####################################
final.cand.prob<-c()
final.cand.models<-c()

for(mcmc.goh in 1:SS.size){
log.post.N<-rep(-Inf,L)
cand.model.N<-matrix(0,L,L)
#Step 1: Compute nbd
for(ii in 1:L){
MCMC.gamma.new<-MCMC.gamma
MCMC.gamma.new[ii]<-1-MCMC.gamma[ii]
cand.model.N[ii,]<-MCMC.gamma.new
}
for(ii in 1:L){
MCMC.gamma.nbd<-cand.model.N[ii,]
if(sum(MCMC.gamma.nbd)<L/2){
hat.R<-cbind(hat.d,Z[,MCMC.gamma.nbd==1])
R<-cbind(d,Z[,MCMC.gamma.nbd==1])
hat.tRR<-crossprod(hat.R)
####################
#hat.sig2 ##########
inv.tRR<-solve(hat.tRR)
tilde.theta.w<-inv.tRR%*%(t(hat.R)%*%y)
hat.y.w<-(R%*%tilde.theta.w)
hat.sig2<-sum((y-hat.y.w)^2)/n

#log Post prob #########
W<-c(1,which(MCMC.gamma.nbd==1)+1)
tRPR_delta0<-hat.tRR+hat.sig2*D[W,W]
inv.tRPR_delta0<-solve(tRPR_delta0)
hat.theta.w<-inv.tRPR_delta0%*%(t(hat.R)%*%y)
P.z.hat.y<-(hat.R%*%hat.theta.w)

log.post.ii<-as.numeric((sum(MCMC.gamma.nbd)+1-L)/2*log(2*pi*hat.sig2)-
1/2*(determinant(tRPR_delta0,logarithm = TRUE)$modulus[1])-
1/(2*hat.sig2)*sum((P.z.y-P.z.hat.y)^2))-
delta0/2*(hat.theta.w[1]^2)
log.post.N[ii]<-log.post.ii 
if(max.log.post<=(log.post.ii+cut.off)){
if(!is.element(log.post.ii,final.cand.prob)){
final.cand.prob<-c(final.cand.prob,log.post.ii)
max.log.post<-max(final.cand.prob)
final.cand.models<-rbind(final.cand.models,MCMC.gamma.nbd)
#update A
A<-which((max.log.post-final.cand.prob)<=cut.off)
final.cand.prob<-final.cand.prob[A]
final.cand.models<-final.cand.models[A,]
}} 
	}
}

prob.prop.N<-exp(tau*log.post.N-tau*max(log.post.N))
prob.N<-prob.prop.N/sum(prob.prop.N)
jj.SSS<-sample(1:L,1,prob=prob.N)
MCMC.gamma.old.jj<-MCMC.gamma[jj.SSS]
MCMC.gamma[jj.SSS]<-1-MCMC.gamma.old.jj
#print(which(MCMC.gamma==1))
}

final.cand<-1:length(final.cand.prob) 
prop.prob.cand<-exp(final.cand.prob)
prob.BMA<-prop.prob.cand/sum(prop.prob.cand)

##########################################
beta.proposed.BMA<-0*prob.BMA
var.proposed.BMA<-0*prob.BMA

for(A.i in final.cand){

if(length(final.cand)==1){
MCMC.gamma<-final.cand.models
}else{
MCMC.gamma<-final.cand.models[A.i,]
}
print(which(MCMC.gamma==1))

hat.R<-cbind(hat.d,Z[,MCMC.gamma==1])
R<-cbind(d,Z[,MCMC.gamma==1])
hat.tRR<-crossprod(hat.R)
####################
#hat.sig2 ##########
inv.tRR<-solve(hat.tRR)
tilde.theta.w<-inv.tRR%*%(t(hat.R)%*%y)
hat.y.w<-(R%*%tilde.theta.w)
hat.sig2<-sum((y-hat.y.w)^2)/n
#log Post prob #########
########################
W<-c(1,which(MCMC.gamma==1)+1)
tRPR_delta0<-hat.tRR+hat.sig2*D[W,W]
inv.tRPR_delta0<-solve(tRPR_delta0)
hat.theta.w<-inv.tRPR_delta0%*%(t(hat.R)%*%y)

beta.proposed.BMA[A.i]<-hat.theta.w[1]
var.proposed.BMA[A.i]<-hat.sig2*inv.tRPR_delta0[1,1]
}

#####################
#BMA formula 
#####################
hat.beta.BMA2<-sum(beta.proposed.BMA*prob.BMA)
hat.se.BMA2<-sqrt(sum((var.proposed.BMA+beta.proposed.BMA^2)*prob.BMA)-hat.beta.BMA2^2)

#Bias #########################
################################
Est.summary[goh,]<-(c(hat.beta.or,hat.beta.naive,hat.beta.m,hat.beta.lasso.cv,hat.beta.post_lasso,hat.beta.alasso.cv,hat.beta.post_alasso,hat.beta.BMA,hat.beta.BMA2)-beta)

#95%Coverage Probability ######
###############################
#"2SLS_or","2SLS_naive","Post_Lasso","Post_Alasso_cv","BMA")
UB.or<-hat.beta.or+hat.se.or*qnorm(0.975)
UB.naive<-hat.beta.naive+hat.se.naive*qnorm(0.975)
UB.lasso<-hat.beta.post_lasso+hat.se.post_lasso*qnorm(0.975)
UB.alasso<-hat.beta.post_alasso+hat.se.post_alasso*qnorm(0.975)
LB.or<-hat.beta.or-hat.se.or*qnorm(0.975)
LB.naive<-hat.beta.naive-hat.se.naive*qnorm(0.975)
LB.lasso<-hat.beta.post_lasso-hat.se.post_lasso*qnorm(0.975)
LB.alasso<-hat.beta.post_alasso-hat.se.post_alasso*qnorm(0.975)

LB.BMA<-hat.beta.BMA-hat.se.BMA*qnorm(0.975)
UB.BMA<-hat.beta.BMA+hat.se.BMA*qnorm(0.975)
LB.BMA2<-hat.beta.BMA2-hat.se.BMA2*qnorm(0.975)
UB.BMA2<-hat.beta.BMA2+hat.se.BMA2*qnorm(0.975)

Est.CP[goh,1]<-as.numeric((UB.or>beta)&(LB.or<beta))
Est.CP[goh,2]<-as.numeric((UB.naive>beta)&(LB.naive<beta))
Est.CP[goh,3]<-as.numeric((UB.lasso>beta)&(LB.lasso<beta))
Est.CP[goh,4]<-as.numeric((UB.alasso>beta)&(LB.alasso<beta))
Est.CP[goh,5]<-as.numeric((UB.BMA>beta)&(LB.BMA<beta))
Est.CP[goh,6]<-as.numeric((UB.BMA2>beta)&(LB.BMA2<beta))
Est.Var[goh,]<-(c(hat.se.or,hat.se.naive,hat.se.post_lasso,hat.se.post_alasso,hat.se.BMA,hat.se.BMA2))^2
print(paste(goh,"-th simulation running","with","n=",n,",Model=",Model,",case=",Scenario))
}

Var.est<-rep(NA,9)
Var.est[c(1,2,5,7,8,9)]<-apply(Est.Var,2,mean)
CP.est<-rep(NA,9)
CP.est[c(1,2,5,7,8,9)]<-apply(Est.CP,2,mean)

#bias ###################
result.table<-t(rbind(apply(Est.summary,2,mean),
#Var ###################
Var.est,
#MSE ###################
apply((Est.summary)^2,2,mean),
#95% CP ################
CP.est))
colnames(result.table)<-c("Bias","Var","MSE","95% CP")
rownames(result.table)<-c("oracle_TSLS","naive_TSLS","median","lasso","post-lasso","alasso","post-alasso","Traditional_Bayes","Proposed_Bayes")
table.1.sub<-round(result.table[c(2:9,1),],4)

file.name<-paste("Table1_n",n,"Model",Model,"_Case",Scenario,".csv",sep="")
#setwd('C:/Users/Goh/Dropbox/YG-Projects/Paper3_bayesian_IV/Oxford_Bulletin_Econ_Stat/Revision_I/Rcode_Simulation_study/Simulation_result')
#setwd('D:/Dropbox/YG-Projects/Paper3_bayesian_IV/Oxford_Bulletin_Econ_Stat/Revision_II/Simulation_result')
setwd('/Users/jisangyu/Dropbox/High_dimensional_Bayesian/Paper3_bayesian_IV/Oxford_Bulletin_Econ_Stat/Revision_II/Simulation_result')

write.csv(table.1.sub,file.name)

}}






